import 'dart:io';

class VehicleImage{
  String id;

  String image;

  VehicleImage({
    this.id,
    this.image,
   
  });
}