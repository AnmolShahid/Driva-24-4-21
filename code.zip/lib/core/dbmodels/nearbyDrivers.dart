class NearbyDrivers{
  String key;
  double latitude;
  double longitude;

  NearbyDrivers({
    this.key,
    this.latitude,
    this.longitude
  });
}