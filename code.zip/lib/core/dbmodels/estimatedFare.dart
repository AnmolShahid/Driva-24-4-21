import 'package:firebase_database/firebase_database.dart';

class EstimatedFare{

  int base_EstimatedFare;
  double time_EstimatedFare;
  double distance_EstimatedFare;
  int total_EstimatedFare;


  EstimatedFare({
    this.base_EstimatedFare,
    this.time_EstimatedFare,
    this.distance_EstimatedFare,
    this.total_EstimatedFare

  });

 
}