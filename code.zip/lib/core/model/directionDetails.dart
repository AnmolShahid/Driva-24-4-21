class DirectionDetails{
  String distanceText;
  String durationText;
  int distanceValue;
  int durationValue;
  String encodedPoints;


  DirectionDetails({
    this.distanceText,
    this.distanceValue,
    this.durationText,
    this.durationValue,
    this.encodedPoints,
  });
}